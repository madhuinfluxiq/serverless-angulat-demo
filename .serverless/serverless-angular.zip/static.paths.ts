// specifies additional routes for prerender
const routeData = {
	hostname: '',
	routes: [],
};

export default routeData;